﻿using Microsoft.AspNetCore.Mvc;
using Swashbuckle.AspNetCore.Annotations;
using WebAPI.Helpers;
using WebAPI.Models;

namespace WebAPI.Routes
{
    public static class UserRoutes
    {
        public static void MapUserRoutes(this WebApplication app)
        {
            app.MapGet("/api/users", async ([FromServices] IConfiguration config) =>
            {
                string connStr = config.GetConnectionString("DefaultConnection");
                var users = await SqlHelper.GetUsersAsync(connStr);
                return Results.Ok(users);
            })
            .WithName("GetAllUsers")
            .WithTags("Users")
            .WithMetadata(new SwaggerOperationAttribute(
                summary: "Get all users",
                description: "Returns list of all active/inactive users along with role details"
            ))
            .Produces<List<UserModel>>(StatusCodes.Status200OK)
            .Produces(StatusCodes.Status500InternalServerError);

            app.MapPost("/api/users", async (
     [FromServices] IConfiguration config,
     [FromBody] CreateUserRequest user) =>
            {
                var connStr = config.GetConnectionString("DefaultConnection");
                var result = await SqlHelper.CreateUserAsync(connStr, user);

                return result
                    ? Results.Ok(new { message = "User created successfully." })
                    : Results.BadRequest(new { message = "User creation failed." });

            })
                 .WithName("CreateUser")
 .WithTags("Users")
 .WithMetadata(new SwaggerOperationAttribute(
     summary: "Create new user",
     description: "Creates a new user with hashed password and role"
 ))
 .Produces(StatusCodes.Status200OK)
 .Produces(StatusCodes.Status400BadRequest);

            app.MapPut("/api/users/{id}", async (
    int id,
    [FromServices] IConfiguration config,
    [FromBody] UpdateUserRequest user) =>
            {
                var connStr = config.GetConnectionString("DefaultConnection");
                var result = await SqlHelper.UpdateUserAsync(connStr, id, user);

                return result
                    ? Results.Ok(new { message = "User updated successfully." })
                    : Results.NotFound(new { message = "User not found." });

            })
.WithName("UpdateUser")
.WithTags("Users")
.WithMetadata(new SwaggerOperationAttribute(
    summary: "Update user",
    description: "Updates a user's name, email, and role"
))
.Produces(StatusCodes.Status200OK)
.Produces(StatusCodes.Status404NotFound);

            app.MapDelete("/api/users/{id}", async (
    int id,
    [FromServices] IConfiguration config) =>
            {
                var connStr = config.GetConnectionString("DefaultConnection");
                var result = await SqlHelper.SoftDeleteUserAsync(connStr, id);

                return result
                    ? Results.Ok(new { message = "User deactivated successfully." })
                    : Results.NotFound(new { message = "User not found." });

            })
.WithName("SoftDeleteUser")
.WithTags("Users")
.WithMetadata(new SwaggerOperationAttribute(
    summary: "Deactivate (soft delete) user",
    description: "Marks a user as inactive without removing their data"
))
.Produces(StatusCodes.Status200OK)
.Produces(StatusCodes.Status404NotFound);

        }
    }
}
